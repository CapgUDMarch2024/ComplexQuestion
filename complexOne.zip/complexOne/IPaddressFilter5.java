package com.capgem.complexOne;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IPaddressFilter5 {
    public static void main(String[] args)
    {

        // String containing in it
        String str
                = "\"123.123.23.123 - - [26/Apr/2000:00:23:48 -0400] \\\"\"GET /pics/wpaper.gif HTTP/1.0\\\"\" 200 6248 \\\"\"http:// www.jafsoft.com/asctortf/\\\"\" \\\"\"Mozilla/4.05 (Macintosh; I; PPC)\\\"\"\\n\"\"\r\n"
                + "                          + \"\"123.123.123.123 - - [26/Apr/2000:00:23:47 -0400] \\\"\"GET /asctortf/ HTTP/1.0\\\"\" 200 8130 \\\"\"http:// search.netscape.com/Computers/Data_Formats/Document/Text/RTF\\\"\" \\\"\"Mozilla/4.05 (Macintosh; I; PPC)\\\"\"\\n\"\"\r\n"
                + "                          + \"\"123.123.123.124 - - [26/Apr/2000:00:23:48 -0400] \\\"\"GET /pics/5star2000.gif HTTP/1.0\\\"\" 200 4005 \\\"\"http:// www.jafsoft.com/asctortf/\\\"\" \\\"\"Mozilla/4.05 (Macintosh; I; PPC)\\\"\"\\n\"\"\r\n"
                + "                          + \"\"123.123.123.123 - - [26/Apr/2000:00:23:50 -0400] \\\"\"GET /pics/5star.gif HTTP/1.0\\\"\" 404 1031 \\\"\"http:// www.jafsoft.com/asctortf/\\\"\" \\\"\"Mozilla/4.05 (Macintosh; I; PPC)\\\"\"\\n\"\"\r\n"
                + "                          + \"\"123.123.123.124 - - [26/Apr/2000:00:23:51 -0400] \\\"\"GET /pics/a2hlogo.jpg HTTP/1.0\\\"\" 200 4282 \\\"\"http:// www.jafsoft.com/asctortf/\\\"\" \\\"\"Mozilla/4.05 (Macintosh; I; PPC)\\\"\"\\n\"\"\r\n";

        System.out.println("Available IP Addresses in the Given String Are:");
        extractIP_Addresses(str);
    }

    // Function to extract IP Address
    // from a given string
    static void extractIP_Addresses(String str)
    {

        // You can Add n number of Email
        // formats in the below given
        // String Array.
        String strPattern[] = {
                "(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})",
                "((([0-9a-fA-F]){1,4})\\:){7}([0-9a-fA-F]){1,4}"
        };

        // Extracting all Patterns from the string
        for (int i = 0; i < strPattern.length; i++) {
            Pattern pattern = Pattern.compile(strPattern[i]);
            Matcher matcher = pattern.matcher(str);
            while (matcher.find()) {
                System.out.println(matcher.group());
            }
        }
    }
}
