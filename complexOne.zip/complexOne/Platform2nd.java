package com.capgem.complexOne;

public class Platform2nd {
    static int findPlatforms(int n, int arrival[],int departure[])
    {
        int res=1;
        for(int i=0; i<=n-1; i++)   //outer for loop
        {
//count of overlapping interval of only this iteration
            int count=1;
            for(int j=i+1; j<=n-1; j++) //inner for loop
            {
//&& returns true if both conditions are true
// || returns true if any one condition becomes true
                if((arrival[i]>=arrival[j] && arrival[i]<=departure[j]) || (arrival[j]>=arrival[i] && arrival[j]<=departure[i]))
                {
//increments the count variable by 1 if any of the condition becomes true
                    count++;
                }
            }
//finds the maximum value and updating the result
            res = Math.max(res, count);
        }
        return res;
    }
    public static void main (String args[])
    {
//initializing the arrival and departure time in an array
        int[] arrival = {900, 945, 955, 1100, 1500, 1800};
        int[] departure = {920, 1200, 1130, 1150, 1900, 2000};
//finds the length of the arrival time array
        int n=arrival.length;
//function calling
        int totalCount = findPlatforms(n, arrival, departure);
//prints the result on the console
        System.out.println("Minimum number of Platforms required: "+totalCount);
    }
}
