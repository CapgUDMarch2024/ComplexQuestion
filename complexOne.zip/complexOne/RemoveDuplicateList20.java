package com.capgem.complexOne;

import java.util.*;

public class RemoveDuplicateList20 {
    public static void main(String[] args) {
        List list1=new ArrayList();
        list1.add(4);
        list1.add(5);
        List list2=new ArrayList();
        list2.add(6);
        list2.add(1);
        List list3=new ArrayList();
        list3.add(4);
        list3.add(5);
        List list4=new ArrayList();
        list4.add(6);
        list4.add(1);

        List list=new ArrayList();
        list.addAll(list1);
        list.addAll(list2);
        list.addAll(list3);
        list.addAll(list4);

        Set set=new HashSet(list);

        System.out.println(set);
    }
}