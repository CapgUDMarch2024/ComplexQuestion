package com.capgem.complexOne;

import java.text.DecimalFormat;
import java.util.Scanner;

public class RupeesCoinCombo7 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        DecimalFormat decimalFormat = new DecimalFormat("0.00");

        System.out.println("Please Enter an amount of Money:");
        double change = input.nextDouble();


        int dollars = (int)change;
        // int twenties = dollars / 50;
        // int dollars1 = dollars % 50;
        int tens = dollars / 10;
        int dollars2 = dollars % 10;
        int fives = dollars2 / 5;
        int dollars3 = dollars % 5;
        int two = dollars3/2;
        int dollars4 = dollars % 2;

        String moneyString = decimalFormat.format(change);
        String changeString = Double.toString(change);
        String[] parts = moneyString.split("\\.");

        System.out.println("Input entered by user: " + "$" + moneyString);


        //System.out.println(twenties + " Twenties");
        System.out.println(tens + " Tens");
        System.out.println(fives + " Fives");
        System.out.println(two + " two");

    }
}