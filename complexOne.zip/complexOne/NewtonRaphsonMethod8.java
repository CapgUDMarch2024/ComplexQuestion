package com.capgem.complexOne;

public class NewtonRaphsonMethod8 {
    public static double findSqrt(double N, double guess,
                                  double tolerance)
    {
        double nextGuess = (guess + N / guess) / 2;
        if (Math.abs(guess - nextGuess) <= tolerance) {
            return nextGuess;
        }
        else {
            return findSqrt(N, nextGuess, tolerance);
        }
    }

    public static void main(String[] args)
    {
        double N = 327, L = 0.00001;
        double guess = N / 2; // Initialize the guess to N/2
        double sqrt = findSqrt(N, guess, L);
        System.out.printf("%.4f%n", sqrt);
    }
}
