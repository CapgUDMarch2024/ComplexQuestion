package com.capgem.complexOne;

public class DotProduct19 {
    public static double dotProduct(int[] a, int[] b) {
        double sum = 0;
        for (int i = 0; i < a.length; i++) {
            sum += a[i] * b[i];
        }
        return sum;
    }
    public static void main (String [] args) {

        int[] a = {1,2,2,1};
        int[] b = {1,2,2,1};

        System.out.println(dotProduct(a, b));
    }
}
