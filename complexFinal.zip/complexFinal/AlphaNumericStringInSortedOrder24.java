package com.capgeme.complexFinal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AlphaNumericStringInSortedOrder24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		String[] str={"1","A","B","C","2","3","F","V","5"};
		
		List<String> list=new ArrayList<String>();
		
		for(int i= 0 ; i <str.length ;i++) {
			list.add(str[i]);
		}
		
		Collections.sort(list);
		
		System.out.println(list);
	}

}
