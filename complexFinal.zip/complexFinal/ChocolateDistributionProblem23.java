package com.capgeme.complexFinal;

import java.util.ArrayList;
import java.util.List;

public class ChocolateDistributionProblem23 {
	//Recursive function to get all the
    //Subsets of size m.
    public static void subSet(int[] arr, int idx, List<List<Integer>> list, List<Integer> l, int m){
        
        //Base Case
        if(idx == arr.length){
            if(l.size() == m  ){
                list.add(new ArrayList<>(l));
            }
            return;
        }
        
        //Including the element in subset
        //Adding element in the 1D ArrayList
        l.add(arr[idx]);
        subSet(arr, idx+1, list, l, m);
        
        //Removing element from the 1D ArrayList (BackTracking)
        l.remove(l.size() - 1);
        
        //Excluding the element
        subSet(arr, idx+1, list, l, m);
    }
    
    //Minimum element from the subset
    public static int findMin(List<Integer> l){
        int min = Integer.MAX_VALUE;
        for(int i : l){
            min = Math.min(min, i);
        }
        return min;
    }
    
    //Maximum element from the subset
    public static int findMax(List<Integer> l){
        int max = Integer.MIN_VALUE;
        for(int i : l){
            max = Math.max(max, i);
        }
        return max;
    }
    
    //main function
    public static void main(String args[]) {
        
        //2D ArrayList to store all the subsets
        List<List<Integer>> list = new ArrayList<>();
        
        //1D ArrayList to store the perticular subset
        List<Integer> l = new ArrayList<>();
        
        // arr[0..n-1] represents sizes of packets
        int[] arr = {3, 4, 1, 9, 56, 7, 9, 12};
        
         //Number of students
        int m = 5;
        
        //Recursive function
        subSet(arr, 0, list, l, m);
        
        int ans = Integer.MAX_VALUE;
        
        //Finding the  minimum difference between
        //Maximum and minimum values of
        //Distribution.
        for(List<Integer> i : list){
            int min = findMin(i);
            int max = findMax(i);
            int diff = max - min;
            ans = Math.min(ans, diff);
        }
        
        //Printing the minimum difference
        System.out.println(ans);
    }

}
