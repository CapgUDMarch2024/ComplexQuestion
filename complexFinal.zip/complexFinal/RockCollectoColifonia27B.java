package com.capgeme.complexFinal;

public class RockCollectoColifonia27B {
    public static int optimalPath(int[][] arr) {

        int row = arr.length;
        int col = arr[0].length;
        int ans = 0;
        int[][] dp = new int[row][col];
        for(int i=0; i<row;i++){
            for(int j=col-1;j>=0;j--){
                if(i == 0 && j == col-1) dp[i][j] = arr[i][j];
                else if(i == 0) dp[i][j] = arr[i][j] + dp[i][j+1];
                else if(j==col-1) dp[i][j] = arr[i][j] + dp[i-1][j];
                else dp[i][j] = arr[i][j] + Math.max(dp[i-1][j], dp[i][j+1]);
            }
        }
        return dp[row-1][0];
    }
    public static void main(String[] args) {
        int[][] grid = {{0, 0, 0, 0, 5},
                {0, 1, 1, 1, 0},
                {2, 0, 0, 0, 0}};
        System.out.println(optimalPath(grid));
    }
}
