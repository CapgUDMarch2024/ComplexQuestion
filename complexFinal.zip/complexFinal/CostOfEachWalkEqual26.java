package com.capgeme.complexFinal;

public class CostOfEachWalkEqual26 {
    static int [][]G = new int[250][250];
    static int []Maxedge = new int[250];
    static int [][]B = new int[250][250];
    static int l = 0, n, m;

    // Function return total
// walk of length N
    static int TotalWalks(int cost)
    {
        int ans = 0;

        // Add values of all
        // node with cost X
        for(int i = 1; i <= n; i++)
        {
            ans += B[i][cost];
        }

        return ans;
    }

    // Function to precompute array B
// mentioned above
    static void DFS(int u, int v, int len)
    {
        // Base condition
        if (l == len)
        {

            // Updating the matrix B when
            // we get a walk of length N.
            B[u][ Maxedge[len]]++;
            return;
        }

        for (int i = 1; i <= n; i++)
        {
            if (G[v][i] !=0)
            {

                // Incrementing the length
                // of the walk
                l++;

                // Updating the cost of the walk
                Maxedge[l] = Math.max(Maxedge[l - 1],
                        G[v][i]);
                DFS(u, i, len);
                l--;
            }
        }
    }

    // Function to calculate total
// number of walks of length N
    static void NumberOfWalks(int cost,int len)
    {
        for(int i = 1; i <= n; i++)
        {

            // Calling the function DFS
            DFS(i, i, len);
        }

        int ans = TotalWalks(cost);

        // Print the answer
        System.out.print(ans + "\n");
    }

    // Driver code
    public static void main(String[] args)
    {
        int Cost = 2;
        n = 3; m = 3;
        int length = 4;

        // Create a graph given in
        // the above diagram
        G[1][2] = 1;
        G[2][1] = 1;
        G[2][3] = 2;
        G[3][2] = 2;
        G[1][3] = 3;
        G[3][1] = 3;

        NumberOfWalks(Cost, length);
    }
}
