package com.capgeme.complexFinal;

public class MinimumElementsRequiredForTarget10 {
    // Function to find the count of
// minimum length of the sequence
    static int Count(int S[], int m, int n)
    {
        int [][]table = new int[m + 1][n + 1];

        // Loop to initialize the array
        // as infinite in the row 0
        for(int i = 1; i <= n; i++)
        {
            table[0][i] = Integer.MAX_VALUE - 1;
        }

        // Loop to find the solution
        // by pre-computation for the
        // sequence
        for(int i = 1; i <= m; i++)
        {
            for(int j = 1; j <= n; j++)
            {
                if (S[i - 1] > j)
                {
                    table[i][j] = table[i - 1][j];
                }
                else
                {

                    // Minimum possible for the
                    // previous minimum value
                    // of the sequence
                    table[i][j] = Math.min(table[i - 1][j],
                            table[i][j - S[i - 1]] + 1);
                }
            }
        }
        return table[m][n];
    }

    // Driver Code
    public static void main(String[] args)
    {
        int arr[] = { 1,2,3,4 };
        int m = arr.length;

        System.out.println(Count(arr, m, 6));
        //System.out.println(Count(arr, m, 12));
    }
}
